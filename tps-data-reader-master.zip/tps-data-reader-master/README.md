# tps-data-reader
Top Speed Database Reader
A C# library for reading a TPS database.

### Binaries (dist)
* TSPReader.dll
	* Include this in your .NET project 
* TPSReaderCMD.exe
	* Command line tool to convert TPS into CSVs
* TPSReaderGUI.exe
	* Simple GUI application to convert TPS files
	
### Source (src)
	Latest version is build with Visual Studio 2017

### Thank You
Special thanks to E.Hooijmeijer for his work on tps-to-csv ( http://ctrl-alt-dev.nl/Projects/TPS-to-CSV/TPS-to-CSV.html )
