﻿using System;
using System.Data;
using System.Windows.Forms;

namespace TPSReaderGUI
{
    /// <summary>
    /// Description of DataTableViewerForm.
    /// </summary>
    public partial class DataTableViewerForm : Form
    {
        private DataTable _dataTable;

        public DataTableViewerForm(DataTable dataTable)
        {
            // Initialize the form and set the data source for the DataGridView
            InitializeComponent();
            _dataTable = dataTable;
            dataGridView1.DataSource = _dataTable;
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            // Enable editing in the DataGridView
            dataGridView1.ReadOnly = false;
            MessageBox.Show("Chế độ chỉnh sửa đã bật. Bạn có thể chỉnh sửa dữ liệu.", "Thông báo");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Disable editing and save changes back to the DataTable
            dataGridView1.EndEdit();
            dataGridView1.ReadOnly = true;

            try
            {
                // Save the updated DataTable back to the TPS file
                SaveChangesToTPSFile(_dataTable);

                MessageBox.Show("Dữ liệu đã được lưu thành công!", "Lưu hoàn tất");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi lưu dữ liệu: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void SaveChangesToTPSFile(DataTable updatedTable)
        {
            // Placeholder for TPS save logic.
            // You need to connect this with the TPSReader SaveTableData method.
            int tableID = 1; // Replace this with the actual table ID for your TPS file
            TPSReader reader = new TPSReader("path/to/your/file.tps");
            reader.Open();
            reader.SaveTableData(updatedTable, tableID);
            reader.Close();
        }
    }
}