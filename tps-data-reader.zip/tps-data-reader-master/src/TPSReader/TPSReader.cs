﻿/*
 *  Copyright 2014 C.Chenier
 *  Special thanks to E.Hooijmeijer for his work on tps-to-csv ( http://ctrl-alt-dev.nl/Projects/TPS-to-CSV/TPS-to-CSV.html )
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
using System;
using System.IO;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace TPSReader
{
    /// <summary>
    /// Description of TPSReader.
    /// </summary>
    public class TPSReader
    {
        private string _filename;
        private TPSHeader _tpsHeader;
        private List<TPSBlock> _tpsBlocks;
        private List<TPSPage> _tpsPages;
        private TableSchemaCollection _tpsTables;

        private bool _tableInfoLoaded = false;

        private string _log = "";

        #region public variables
        public TPSHeader TpsHeader
        {
            get { return _tpsHeader; }
        }
        public List<TPSBlock> TpsBlocks
        {
            get { return _tpsBlocks; }
        }
        public List<TPSPage> TpsPages
        {
            get { return _tpsPages; }
        }
        public TableSchemaCollection TPSTables
        {
            get { return _tpsTables; }
        }
        #endregion

        public TPSReader(string filename)
        {
            _filename = filename;
        }

        public void Open()
        {
            RandomAccess ra = RandomAccess.GetInstance();
            ra.OpenFile(_filename);
            _log += "INFO: Opened File: " + _filename;
        }

        public void Process()
        {
            _tpsTables = new TableSchemaCollection();
            ReadTPSHeaderInfo();
            GetTPSPageInfo();
            GetTPSTableSchema();
        }

        public void Close()
        {
            RandomAccess.GetInstance().CloseFile();
        }

        public DataSet GetTableData()
        {
            return GetTableData(_tpsTables);
        }

        public DataSet GetTableData(TableSchemaCollection tableSchemas)
        {
            DataSet retSet = new DataSet();
            if (tableSchemas.Count < 1) return retSet;

            Dictionary<int, DataTable> dataTables = new Dictionary<int, DataTable>();
            foreach (TableSchema schema in tableSchemas.Values)
            {
                DataTable dt = schema.BuildEmptyDataTable();
                dataTables.Add(schema.TableID, dt);
            }

            try
            {
                foreach (TPSPage page in _tpsPages)
                {
                    List<TPSRecord> pageRecords = page.GetRecords();
                    foreach (TPSRecord record in pageRecords)
                    {
                        if (record.RecordType == TPSRecord.TYPE_DATA)
                        {
                            byte[] recordTableIDBA = new byte[4];
                            if (record.RecordData.Length < 4) continue;

                            recordTableIDBA[0] = record.RecordData[3];
                            recordTableIDBA[1] = record.RecordData[2];
                            recordTableIDBA[2] = record.RecordData[1];
                            recordTableIDBA[3] = record.RecordData[0];

                            int recordTableID = BitConverter.ToInt32(recordTableIDBA, 0);

                            if (tableSchemas.ContainsKey(recordTableID))
                            {
                                Record.TableDataRecord tdr = new Record.TableDataRecord(record, tableSchemas[recordTableID]);
                                dataTables[recordTableID].Rows.Add(tdr.TableDataRow.ItemArray);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error searching for data: ", ex);
            }
            foreach (DataTable dt in dataTables.Values)
                retSet.Tables.Add(dt);

            return retSet;
        }

        /// <summary>
        /// Saves updated data back to the TPS file.
        /// </summary>
        /// <param name="dataTable">The updated DataTable to save.</param>
        /// <param name="tableID">The ID of the table being updated.</param>
        public void SaveTableData(DataTable dataTable, int tableID)
        {
            if (!_tpsTables.ContainsKey(tableID))
                throw new Exception("Table ID does not exist in the current TPS file.");

            RandomAccess ra = RandomAccess.GetInstance();
            ra.OpenFile(_filename); // Open TPS file for writing

            try
            {
                // Iterate through each row in the DataTable and write back to the TPS file
                foreach (DataRow row in dataTable.Rows)
                {
                    byte[] dataToWrite = _tpsTables[tableID].SerializeRow(row);
                    ra.WriteData(tableID, dataToWrite);
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error saving data to TPS file: ", ex);
            }
            finally
            {
                ra.CloseFile(); // Ensure file is closed after saving
            }
        }

        // Other existing methods remain unchanged...
    }
}